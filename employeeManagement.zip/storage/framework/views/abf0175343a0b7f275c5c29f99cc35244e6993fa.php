
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>StaffDetails</title>

    <!-- Bootstrap core CSS -->
    <link href="http://getbootstrap.com/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="http://getbootstrap.com/docs/4.0/examples/signin/signin.css" rel="stylesheet">
</head>

<body>

<div class="container">

    <form action="<?php echo e(route('dailyInput.update',    $dailyInput->id)); ?>" method="POST">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>

        <h2 class="form-signin-heading">Daily Input Edit</h2>

        <input type="hidden" id="id" name="id" class="form-control" value="<?php echo e($dailyInput->id); ?>">

        Staff Name        : <select name="inputStaffDetail">
            <option value="<?php echo e($dailyInput->staffDetail->id); ?>" label="<?php echo e($dailyInput->staffDetail->name); ?>"/>
            <?php $__currentLoopData = $staffDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staffDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($staffDetail->id); ?>" label="<?php echo e($staffDetail->name); ?>"/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br />

        Client Name        : <select name="inputClient">
            <option value="<?php echo e($dailyInput->client->id); ?>" label="<?php echo e($dailyInput->client->name); ?>"/>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($client->id); ?>" label="<?php echo e($client->name); ?>"/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br />

        <label for="inputCreated" class="sr-only">Created</label>
        <input type="text" id="inputCreated" name="inputCreated" class="form-control" value="<?php echo e($dailyInput->created); ?>" readonly>

        <p>Optional</p>
        <label for="inputTimeFrom" class="sr-only">Time From</label>
        <input type="text" id="inputTimeFrom" name="inputTimeFrom" class="form-control" value="<?php echo e($dailyInput->timeFrom); ?>" >

        <p>Optional</p>
        <label for="inputTimeUpto" class="sr-only">Time To</label>
        <input type="text" id="inputTimeUpto" name="inputTimeUpto" class="form-control" value="<?php echo e($dailyInput->timeUpto); ?>" >

        <td>
            <label for="inputTimeTotal" class="sr-only">TotalTime</label>
            <input type="text" id="inputTimeTotal" name="inputTimeTotal" class="form-control" value="<?php echo e($dailyInput->timeTotal); ?>" placeholder="Total Time in hours:minuts" required autofocus>
        </td>

        <td>
            <label for="inputReportDate" class="sr-only">Date</label>
            <input type="date" id="inputReportDate" name="inputReportDate" class="form-control" value="<?php echo e($dailyInput->reportDate); ?>" required autofocus>
        </td>
        <br />
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="submit">Update</button>
    </form>

</div>
<!-- /container -->
</body>
</html>
