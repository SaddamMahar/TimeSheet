<!doctype html>
<html lang="en">
<head>
    <title>Admin</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?> " />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?> " />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?> " />



    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?> "></script>
</head>
<body>
<header>
    <div class="container">
        <div class="header-main">
            <div class="leftNav">
                <nav>
                    <ul>
                        <li class="active"><a href="<?php echo e(URL::to('client')); ?>">Clients </a></li>
                        <li><a href="<?php echo e(URL::to('staffDetail')); ?>">Staff </a></li>
                        <li><a href="<?php echo e(URL::to('task')); ?>">Task </a></li>
                        <li><a href="<?php echo e(URL::to('designation')); ?>">Designation </a></li>
                        <li><a href="<?php echo e(URL::to('charge')); ?>">Charges </a></li>
                        <li><a href="<?php echo e(URL::to('dailyInput')); ?>">DailyInputs </a></li>
                        <li><a href="<?php echo e(URL::to('client')); ?>">Admin </a></li>
                    </ul>
                </nav>
            </div>
            <div class="rightNav">
                <a href="#">Login</a>
            </div>
        </div>
    </div>
</header>
<section class="main">
    <div class="container">
        <h2 class="heading-main">Client  <span class="addIcon" data-toggle="modal" data-target="#myModal"><i><img src="<?php echo e(asset('img/add.png')); ?>" alt=""></i>Add</span></h2>

        <div class="row">
            <div class="col-sm-12">
                <div class="main-table">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Contact</th>
                            <th>Contact Person</th>
                            <th>Ntn</th>
                            <th>Action</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->address); ?></td>
                                <td><?php echo e($client->contact); ?></td>
                                <td><?php echo e($client->contactPerson); ?></td>
                                <td><?php echo e($client->nic); ?></td>
                                <td>
                                    <form action="<?php echo e(route('client.destroy',    $client->id)); ?>" method="POST">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo e(csrf_field()); ?>

                                        <div class="btn-group">
                                            <button class="btn btn-sm">Delete</button>
                                        </div>
                                    </form>
                                    <a class="btn btn-sm" href="<?php echo e(URL::to('client/'.$client->id.'/edit/')); ?>">Edit</a>



                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade modal-small" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span data-dismiss="modal" aria-label="Close" aria-hidden="true" class="closeFixed">&times;</span>
                <h2 class="modal-title" id="myModalLabel">Client Detail</h2>
            </div>
            <div class="modal-body">
                <input type="text" placeholder="Name">
                <input type="text" placeholder="Address">
                <input type="text" placeholder="Phone Number">
                <input type="text" placeholder="Contact Person">
                <input type="text" placeholder="Mobile Number">
                <input type="text" placeholder="NTN">
                <div class="fieldWithLabel">
                    <label for="">Joining Date</label>
                    <input type="text" placeholder="NTN">
                </div>
                <div class="fieldWithLabel">
                    <label for="">Date Picker</label>
                    <input type="text" class="datepick" placeholder="NTN">
                </div>
                <div class="fieldWithLabel">
                    <input type="text" placeholder="NTN">
                </div>
                <div class="fieldWithLabel">
                    <input type="text" placeholder="NTN">
                </div>
                <div class="fieldWithLabel Cell">
                    <label for="">Joining Date</label>
                    <select name="" id="">
                        <option value="">---Select---</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-xs-6 text-center">
                        <button type="button" data-dismiss="modal">Submit</button>
                    </div>
                    <div class="col-xs-6 text-center">
                        <button type="button">Exit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $(".datepick").datepicker({format: 'yyyy-mm-dd'});
    })
</script>
</body>
</html>