
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Charge</title>

    <!-- Bootstrap core CSS -->
    <link href="http://getbootstrap.com/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="http://getbootstrap.com/docs/4.0/examples/signin/signin.css" rel="stylesheet">
</head>

<body>

<div class="container">

    <form action="<?php echo e(route('charge.update',    $charge->id)); ?>" method="POST">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>

        <h2 class="form-signin-heading">Charge Edit</h2>

        <input type="hidden" id="id" name="id" class="form-control" value="<?php echo e($charge->id); ?>">

        <label for="inputRate" class="sr-only">Rate</label>
        <input type="text" id="inputRate" name="inputRate" class="form-control" value="<?php echo e($charge->rate); ?>" required autofocus>

        <label for="inputUpto" class="sr-only">Upto</label>
        <input type="date" id="inputUpto" name="inputUpto" class="form-control" value="<?php echo e($charge->upto); ?>" required>

        Designation        : <select name="inputDesignation">
            <option value="<?php echo e($charge->designation->id); ?>" label="<?php echo e($charge->designation->title); ?>"/>
            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($designation->id); ?>" label="<?php echo e($designation->title); ?>"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br />

        <br />
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="submit">Update</button>
    </form>

</div>
<!-- /container -->
</body>
</html>
