
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Signin Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="http://getbootstrap.com/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="http://getbootstrap.com/docs/4.0/examples/signin/signin.css" rel="stylesheet">
</head>

<body>

<div class="container">

    <form action="<?php echo e(route('client.update',    $client->id)); ?>" method="POST">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>

        <h2 class="form-signin-heading">Client Registration</h2>

        <input type="hidden" id="id" name="id" class="form-control" value="<?php echo e($client->id); ?>">

        <label for="inputName" class="sr-only">Name</label>
        <input type="text" id="inputName" name="inputName" class="form-control" value="<?php echo e($client->name); ?>" required autofocus>

        <label for="inputAddress" class="sr-only">Address</label>
        <input type="text" id="inputAddress" name="inputAddress" class="form-control" value="<?php echo e($client->address); ?>" required>

        <label for="inputContact" class="sr-only">Contact</label>
        <input type="text" id="inputContact" name="inputContact" class="form-control" value="<?php echo e($client->contact); ?>" required>

        <label for="inputContactPerson" class="sr-only">Contact Person</label>
        <input type="text" id="inputContactPerson" name="inputContactPerson" class="form-control" value="<?php echo e($client->contactPerson); ?>" required>

        
        

        <label for="inputnic" class="sr-only">NIC</label>
        <input type="text" id="inputnic" name="inputnic" class="form-control" value="<?php echo e($client->nic); ?>" required>
        <br />
        <br />
        
        
        
        
        
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="submit">Update</button>
    </form>

</div>
<!-- /container -->
</body>
</html>
