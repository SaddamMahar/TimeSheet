<?php



namespace App\Http\Controllers;


use App\Model\DailyInput;
use Carbon\Carbon;
use Couchbase\Document;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Query\Builder;

class ReportController extends Controller{



    public function index(){

        $date = Carbon::now();
        $createdTime = $date->format('Y-m-d');

            if(isset($_REQUEST['ReportDate']) && $_REQUEST['ReportDate'] !=null){
                $createdTime = $_REQUEST['ReportDate'];
            }


            $data = DB::table('daily_inputs')
            ->leftJoin('staff_detail', 'daily_inputs.staff_detail_id', '=', 'staff_detail.id')
            ->leftJoin('designation', 'staff_detail.designation_id', '=', 'designation.id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'), 'client.name AS clientName')
            ->where('client_id', '=' ,'30')
            ->whereDate('created', '=', $createdTime)
            ->groupBy('title')
            ->get();
            if( $data->isEmpty() ){
                $data = null;
            }

        return   view('report.index',compact('data'));
    }

    public function pie(){
//        SELECT *,SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) AS ttime FROM staff_detail
//        LEFT JOIN daily_inputs ON staff_detail.id = daily_inputs.`staff_detail_id`
// WHERE staff_detail.id = '13' GROUP BY daily_inputs.`client_id`

        $data = DB::table('staff_detail')
            ->leftJoin('daily_inputs', 'staff_detail.id', '=', 'daily_inputs.staff_detail_id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'))
            ->where('staff_detail.id', '=' ,'13')
            ->whereDate('created', '=', '2017-11-03')
            ->groupBy('client_id')
            ->get();
//        dd($data);
        return   view('report.pie',compact('data'));
    }


}