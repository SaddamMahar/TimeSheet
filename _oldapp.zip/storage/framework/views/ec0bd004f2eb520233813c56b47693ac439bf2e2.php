<!doctype html>
<html lang="en">
<head>
    <title>Admin</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?> " />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?> " />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?> " />



    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?> "></script>
</head>
<body>
<header>
    <div class="container">
        <div class="header-main">
            <div class="leftNav">
                <nav>
                    <ul>
                        <li><a href="<?php echo e(URL::to('client')); ?>">Clients </a></li>
                        <li><a href="<?php echo e(URL::to('staffDetail')); ?>">Staff </a></li>
                        <li><a href="<?php echo e(URL::to('task')); ?>">Task </a></li>
                        <li><a href="<?php echo e(URL::to('designation')); ?>">Designation </a></li>
                        <li><a href="<?php echo e(URL::to('charge')); ?>">Charges </a></li>
                        <li><a href="<?php echo e(URL::to('dailyInput')); ?>">DailyInputs </a></li>
                        <li class="active"><a href="<?php echo e(URL::to('client')); ?>">Admin </a></li>
                    </ul>
                </nav>
            </div>
            <div class="rightNav">
                <a href="#">Login</a>
            </div>
        </div>
    </div>
</header>
<section class="main">
    <div class="container">
        <h2 class="heading-main">Admin </h2>
        
        <div class="row">
            <form method="post" action="<?php echo e(URL::to('admin')); ?>">
                <?php echo csrf_field(); ?>

                <div class="col-sm-3">
                    <div class="dropdownContainer">
                        <?php if(isset($from)): ?>
                            <input type="text" name="from" class="datepick" placeholder="Start date" value="<?php echo e($from); ?>" onchange="this.form.submit()">
                        <?php else: ?>
                            <input type="text" name="from" class="datepick" placeholder="Start date" onchange="this.form.submit()">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="dropdownContainer">
                        <?php if(isset($upto)): ?>
                            <input type="text" name="upto" value="<?php echo e($upto); ?>" class="datepick" placeholder="End date" onchange="this.form.submit()">
                        <?php else: ?>
                            <input type="text" name="upto" class="datepick" placeholder="End date" onchange="this.form.submit()">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="dropdownContainer">
                        <div class="fieldWithLabel Cell">
                            <label for="inputClient">Client</label>
                            <select name="inputClient" id="inputClient" onchange="this.form.submit()">
                                <?php if(isset($client)): ?>
                                    <option selected value="<?php echo e($client->id); ?>" label="<?php echo e($client->name); ?>"/>
                                <?php else: ?>
                                    <option value="0">---Select---</option>
                                <?php endif; ?>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="dropdownContainer">
                        <div class="fieldWithLabel Cell">
                            <label for="inputStaffDetail">Staff</label>
                            <select name="inputStaffDetail" id="inputStaffDetail" onchange="this.form.submit()">
                                <?php if(isset($staffDetail)): ?>
                                    <option selected value="<?php echo e($staffDetail->id); ?>" label="<?php echo e($staffDetail->name); ?>"/>
                                <?php else: ?>
                                    <option value="0">---Select---</option>
                                <?php endif; ?>
                                <?php $__currentLoopData = $staffDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staffDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($staffDetail->id); ?>"><?php echo e($staffDetail->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="main-table">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Client</th>
                            <th>Staff</th>
                            <th>Designation</th>
                            <th>Hours</th>
                            <th>Rate</th>
                            <th>Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $ttime = 0 ; $trate= 0; $ttotal = 0 ;?>
                        <?php if(isset($dailyInputs)): ?>
                            <?php $__currentLoopData = $dailyInputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailyInput): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dailyInput->reportDate); ?></td>
                                    <td><?php echo e($dailyInput->client->name); ?></td>
                                    <td><?php echo e($dailyInput->staffDetail->name); ?></td>
                                    <td><?php echo e($dailyInput->staffDetail->designation->title); ?></td>
                                    <td><?php echo e($dailyInput->timeTotal); ?></td>
                                    <td><?php echo e($dailyInput->staffDetail->designation->charge->last()->rate); ?></td>

                                    <?php $HRS  = date('H',strtotime($dailyInput->timeTotal)).'.'.date('i',strtotime($dailyInput->timeTotal));  ?>
                                        <?php $ttime += $dailyInput->timeTotal;?>
                                    <?php $trate += $dailyInput->staffDetail->designation->charge->last()->rate;?>
                                    <?php $ttotal += $HRS * $dailyInput->staffDetail->designation->charge->last()->rate;?>
                                    <td><?php echo e($HRS * $dailyInput->staffDetail->designation->charge->last()->rate); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="4" align="right"><strong>Total</strong></td>
                            <td><?php echo e($ttime); ?></td>
                            <td><?php echo e($ttotal/$ttime); ?></td>
                            <td><?php echo e($ttotal); ?></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>



    
        
            
                
                
            
            
                
                
                
                
                
                
                
                    
                    
                
                
                    
                    
                
                
                    
                
                
                    
                
                
                    
                    
                        
                    
                
            
            
                
                    
                        
                    
                    
                        
                    
                
            
        
    


<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $(".datepick").datepicker({format: 'yyyy-mm-dd'});
    })
</script>
</body>
</html>