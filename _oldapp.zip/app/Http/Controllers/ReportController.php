<?php



namespace App\Http\Controllers;


use App\Model\DailyInput;
use App\Model\StaffDetail;
use Carbon\Carbon;
use Couchbase\Document;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Query\Builder;


class ReportController extends Controller{



    public function clientreport(){

        $date = Carbon::now();
        $fromDate =$date->format('Y-m-1'); //From current month start
        $todate = $date->format('Y-m-d'); //current date
        $clientId = null;
        $staffCount = null;
        $singleStaff = null ;
        $totalDays = null;
        $flag = null;

        if(isset($_REQUEST['submit'])){

            $fromDate = isset($_REQUEST['fromdate']) && $_REQUEST['fromdate'] != null ? $_REQUEST['fromdate'] : '';
            $todate = isset($_REQUEST['todate']) && $_REQUEST['todate'] != null ? $_REQUEST['todate'] : '';
            $clientId = isset($_REQUEST['client_id']) && $_REQUEST['client_id'] != null ? $_REQUEST['client_id'] : '';

        }
        $datetime1 = new \DateTime($fromDate);
        $datetime2 = new \DateTime($todate);
        $interval = $datetime1->diff($datetime2);
        $diffreneceBWDays =  $interval->format('%R%a days');
        $Days =intval(preg_replace('/[^0-9]+/', '', $diffreneceBWDays), 10);
        $totalDays = $Days +1;
        if($clientId == 'indvidual') {

            $data = DB::table('client')
                ->leftJoin('daily_inputs', 'daily_inputs.client_id', '=', 'client.id')
                ->leftJoin('staff_detail', 'daily_inputs.staff_detail_id', '=', 'staff_detail.id')
                ->leftJoin('designation', 'staff_detail.designation_id', '=', 'designation.id')
                ->select('client.*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'),
                    'client.name AS clientName','designation.id AS desgID','staff_detail.id AS sID',
                    'daily_inputs.id AS dID','designation.title AS title')
                ->whereDate('created', '>=', $fromDate)
                ->whereDate('created', '<=', $todate)
                ->groupBy('title','id')
                ->get()
                ->groupBy('id');
            $flag = 'indvidual';
        }elseif($clientId == 'all'){
            $data = DB::table('daily_inputs')
                ->leftJoin('staff_detail', 'daily_inputs.staff_detail_id', '=', 'staff_detail.id')
                ->leftJoin('designation', 'staff_detail.designation_id', '=', 'designation.id')
                ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
                ->select('*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'), 'client.name AS clientName')
                ->whereDate('created', '>=', $fromDate)
                ->whereDate('created', '<=', $todate)
                ->groupBy('title')
                ->get();
            $flag = 'all';
        }else{

        $data = DB::table('daily_inputs')
            ->leftJoin('staff_detail', 'daily_inputs.staff_detail_id', '=', 'staff_detail.id')
            ->leftJoin('designation', 'staff_detail.designation_id', '=', 'designation.id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'), 'client.name AS clientName')
            ->where('client_id', '=' ,$clientId)
            ->whereDate('created', '>=', $fromDate)
            ->whereDate('created', '<=', $todate)
            ->groupBy('title')
            ->get();
        }
        if( $data->isEmpty() ){
            $data = null;
        }


        return view('report.clientreport',compact('data','totalDays','flag'));
    }

    public function index(){

        $date = Carbon::now();
        $createdTime = $date->format('Y-m-d');

            if(isset($_REQUEST['ReportDate']) && $_REQUEST['ReportDate'] !=null){
                $createdTime = $_REQUEST['ReportDate'];
            }


            $data = DB::table('daily_inputs')
            ->leftJoin('staff_detail', 'daily_inputs.staff_detail_id', '=', 'staff_detail.id')
            ->leftJoin('designation', 'staff_detail.designation_id', '=', 'designation.id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('*',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'), 'client.name AS clientName')
            ->where('client_id', '=' ,'30')
            ->whereDate('created', '=', $createdTime)
            ->groupBy('title')
            ->get();
//            dd($data);
//             ->groupBy(function($date) {
//                return \Carbon\Carbon::parse($date->created)->format('d-M-y');
//            });
            if( $data->isEmpty() ){
                $data = null;
            }


        return   view('report.index',compact('data'));
    }

    public function pie(){

        $date = Carbon::now();
        $fromDate =$date->format('1971-1-1'); //From start
        $todate = $date->format('Y-m-d'); //current date
        $staff_id = 'all';
        $staffCount = null;
        $singleStaff = null ;
        $totalDays = null;
        $flag = null;
        if(isset($_REQUEST['submit'])){
            $fromDate = isset($_REQUEST['fromdate']) && $_REQUEST['fromdate'] != null ? $_REQUEST['fromdate'] : '';
            $todate = isset($_REQUEST['todate']) && $_REQUEST['todate'] != null ? $_REQUEST['todate'] : '';
            $staff_id = isset($_REQUEST['staff_id']) && $_REQUEST['staff_id'] != null ? $_REQUEST['staff_id'] : '';
            $datetime1 = new \DateTime($fromDate);
            $datetime2 = new \DateTime($todate);
            $interval = $datetime1->diff($datetime2);
            $diffreneceBWDays =  $interval->format('%R%a days');
            $Days =intval(preg_replace('/[^0-9]+/', '', $diffreneceBWDays), 10);
            $totalDays = $Days +1;

        }

        if($staff_id == 'all'){
            $data = DB::table('staff_detail')
                ->leftJoin('daily_inputs', 'staff_detail.id', '=', 'daily_inputs.staff_detail_id')
                ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
                ->select('staff_detail.*','daily_inputs.id AS did','daily_inputs.timeTotal AS timeTotal'
                    ,'daily_inputs.created AS created'
                    ,'client.name AS clientname',DB::raw('COUNT( created ) AS days'),DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'))
                ->whereDate('created', '>=', $fromDate)
                ->whereDate('created', '<=', $todate)
                ->groupBy('client_id')
                ->get();


//            $totalDays = DB::table('daily_inputs')
//                ->select('*')
//                ->whereDate('created', '>=', $fromDate)
//                ->whereDate('created', '<=', $todate)
//                ->get()
//           ->groupBy(function($date) {
//                return \Carbon\Carbon::parse($date->created)->format('d-M-y');
//            })->count();

                $staffCount = StaffDetail::all()->count();
            $flag = 'all';
        }else if($staff_id == 'indvidual'){
            $data = DB::table('staff_detail')
                ->leftJoin('daily_inputs', 'staff_detail.id', '=', 'daily_inputs.staff_detail_id')
                ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
                ->select('staff_detail.*','daily_inputs.id AS did','daily_inputs.timeTotal AS timeTotal'
                    ,'daily_inputs.created AS created'
                    ,'client.name AS clientname',DB::raw('COUNT( created ) AS days'),DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'))
                ->whereDate('created', '>=', $fromDate)
                ->whereDate('created', '<=', $todate)
                ->groupBy('staff_detail.id')
                ->get();

            $staffCount = StaffDetail::all()->count();
            $flag = 'indvidual';
        } else{

        $data = DB::table('staff_detail')
            ->leftJoin('daily_inputs', 'staff_detail.id', '=', 'daily_inputs.staff_detail_id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('staff_detail.*','client.name AS clientname',DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'))
            ->where('staff_detail.id', '=' ,$staff_id)
            ->whereDate('created', '>=', $fromDate)
            ->whereDate('created', '<=', $todate)
            ->groupBy('client_id')
            ->get();


//            $totalDays = DB::table('daily_inputs')
//                ->select('*')
//                ->where('staff_detail_id', '=' ,$staff_id)
//                ->whereDate('created', '>=', $fromDate)
//                ->whereDate('created', '<=', $todate)
//                ->get()
//                ->groupBy(function($date) {
//                    return \Carbon\Carbon::parse($date->created)->format('d-M-y');
//                })->count();
        }

        if( $data->isEmpty() ){
            $data = null;
        }

        return   view('report.pie',compact('data','staffCount','totalDays','flag'));
    }


    public function allstff(){
        $date = Carbon::now();
        $fromDate =$date->format('1971-1-1'); //From start
        $todate = $date->format('Y-m-d'); //current date


        $data = DB::table('staff_detail')
            ->leftJoin('daily_inputs', 'staff_detail.id', '=', 'daily_inputs.staff_detail_id')
            ->leftJoin('client', 'daily_inputs.client_id', '=', 'client.id')
            ->select('staff_detail.*','daily_inputs.id AS did','daily_inputs.timeTotal AS timeTotal'
                ,'daily_inputs.created AS created'
                ,'client.name AS clientname',DB::raw('COUNT( created ) AS days'),DB::raw('SEC_TO_TIME( SUM( TIME_TO_SEC( `timeTotal` ) ) ) as ttime'))
            ->whereDate('created', '>=', $fromDate)
            ->whereDate('created', '<=', $todate)
            ->groupBy('staff_detail.id')
            ->get();

        $staffCount = StaffDetail::all()->count();
        if( $data->isEmpty() ){
            $data = null;
        }

        return   view('report.allstaff',compact('data','staffCount','totalDays'));
    }


}