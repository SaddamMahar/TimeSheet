<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 10/25/2017
 * Time: 5:01 PM
 */


Route::get('/sadam', function () {
    return 'welocme';
});
